# NO SUBIR AL HOST

No subas a Claude:
- `06_CONTROL/`
- `CHECKSUMS.sha256.json`
- `MANIFEST.json`
- `CLAUDE_SOURCE_AUDIT_102R11.json`
- archivos de línea inglesa
- documentos privados o sensibles sin autorización
- material que no pueda verificarse contra el documento original

Esta cápsula no contiene `EV_HOST_CLAUDE_ES.md` porque no se encontró fuente verificada. Crear ese archivo desde memoria rompería la regla no-inventar.
