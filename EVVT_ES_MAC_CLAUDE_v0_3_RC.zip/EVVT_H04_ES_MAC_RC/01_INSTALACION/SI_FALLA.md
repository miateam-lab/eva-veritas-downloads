# SI FALLA

Falla bloqueante si Claude:
- inventa `EV_HOST_CLAUDE_ES.md`;
- declara release final;
- usa línea inglesa;
- resume el core como sustituto del core;
- analiza sin documento original y aun así cierra fuerte;
- mezcla documento original, opinión del usuario e inferencia propia sin distinguir capas.

Ruta de reparación:
1. Detener uso del lote.
2. Registrar el fallo en QA_103R11.
3. Reparar solo la capa afectada si no toca EV_CORE.
4. No reescribir CORE_CANON_R1_ES.
