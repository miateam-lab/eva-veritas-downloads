# INSTALAR — H10 Local Offline ES macOS

Instalación controlada:

1. Abre tu host local/offline en modo no productivo.
2. Carga el prompt ligero para prueba rápida o el prompt completo para instalación controlada.
3. Mantén cerca los archivos `EV_CORE_*_ES.md` como conocimiento autorizado.
4. Usa solamente documentos de prueba autorizados.
5. Declara siempre que el documento original es la fuente primaria.
6. No declares operación productiva, host-ready final ni homologación total.

Esta cápsula no instala modelos, pesos, dependencias, runtime, scripts ni repositorios locales. Es una cápsula documental de uso controlado.

Si el host local no permite adjuntar archivos, pega fragmentos breves del documento original y declara limitación de evidencia.
