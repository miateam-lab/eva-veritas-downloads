# INSTALAR — H12 Host Documental Humano ES (macOS)

Sube o entrega al host humano los seis archivos `EV_CORE_*_ES.md` cuando el entorno lo permita.

No existe `EV_HOST_HUMAN_DOCUMENTARY_HOST_ES.md` como fuente canónica actual. Por tanto, este host vive solo en UX, prompt, instalación y prueba.

Antes de cualquier análisis, confirma si existe **documento original**. Si no existe, el resultado debe marcar evidencia incompleta.
