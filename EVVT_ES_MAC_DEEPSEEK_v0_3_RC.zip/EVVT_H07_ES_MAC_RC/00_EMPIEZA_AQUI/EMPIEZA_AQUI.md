# EMPIEZA AQUÍ — EVA Veritas H07 DeepSeek ES macOS

Estado: no productivo, no release final, no homologación total.

Esta cápsula corresponde al lote H07 DeepSeek ES de EVA Veritas v0.3 RC. Continúa desde QA_103R13 H06 NotebookLM ES, sin empezar de cero.

Regla crítica: conserva siempre el documento original. En DeepSeek, una respuesta persuasiva, técnica o extensa no sustituye el documento original. El documento original es la base de contraste para preguntas, verificaciones, fechas, fuentes y límites.

Qué contiene:
- Prompt ligero para uso rápido en DeepSeek.
- Prompt completo para instalación controlada en DeepSeek o una prueba API sandbox.
- Núcleo ES copiado desde CORE_CANON_R1_ES sin reescritura.
- Instrucciones de prueba para verificar documento original, límites, trazabilidad y ausencia de línea inglesa.
- Registro de fallback: no existe fuente `EV_HOST_DEEPSEEK_ES`; por tanto no se inventa ese archivo.
- Registro COCO: USER_SIMPLE H10 DeepSeek API es antecedente UX/API controlado, no core ni adapter vigente.

No declares: release final, producción total, host-ready final ni homologación total.
