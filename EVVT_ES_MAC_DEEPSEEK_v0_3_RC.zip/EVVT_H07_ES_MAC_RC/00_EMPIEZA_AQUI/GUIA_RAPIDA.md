# GUÍA RÁPIDA — H07 DeepSeek ES macOS

1. Abre DeepSeek en entorno de prueba, o usa un sandbox sin datos sensibles si se prueba API.
2. Usa `02_LIGERA/PROMPT_LIGERO.txt` para una prueba rápida o `03_COMPLETA/PROMPT_COMPLETO.txt` para instalación más fuerte.
3. Si el host permite contexto o archivos, usa los archivos de `04_CONOCIMIENTO/`.
4. No subas `06_CONTROL/` al host de trabajo; esa carpeta es para auditoría.
5. Mantén visible o adjunto el documento original que se va a analizar.
6. Si usas API, no uses claves reales de producción ni información personal.
7. Si DeepSeek responde sin fuente primaria o sin distinguir inferencia de documento original, el veredicto debe quedar abierto.

Regla transversal: documento original obligatorio en prompt, prueba e instalación. Sin documento original no hay cierre fuerte.
