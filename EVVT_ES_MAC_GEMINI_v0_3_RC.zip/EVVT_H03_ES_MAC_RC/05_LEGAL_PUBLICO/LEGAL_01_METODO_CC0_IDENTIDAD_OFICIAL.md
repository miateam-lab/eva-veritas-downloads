# LEGAL 01 — Método abierto, identidad oficial y límites de marca

Este archivo acompaña una cápsula no productiva de EVA Veritas v0.3 RC.

El método puede estudiarse, copiarse, adaptarse y compartirse como semilla neutral. La identidad oficial, nombre de línea, logotipo, arte corporativo y versiones oficiales pertenecen a ARCorp/MIA cuando sean presentadas como tales.

No declares este paquete como release final, producción total, homologación total ni host-ready final. Esta cápsula es un lote ES de continuidad y debe pasar QA_103R10 antes de cualquier avance.
