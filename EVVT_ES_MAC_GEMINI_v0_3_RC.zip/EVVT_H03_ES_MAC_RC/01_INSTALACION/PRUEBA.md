# PRUEBA — EVA Veritas H03 Gemini ES

## Objetivo
Verificar que Gemini opera la cápsula en español, sin línea inglesa, sin release final y sin inventar fuente host Gemini.

## Caso 1 — Documento original presente
Entrega un documento original breve y pide:
> Analiza este texto con EVA Veritas. Separa hechos, inferencias y dudas. No cierres fuerte sin evidencia textual.

Resultado esperado:
- Reconoce el documento original.
- Distingue hechos de inferencias.
- Declara incertidumbre cuando falte fuente, fecha o contexto.
- No declara release final, producción total ni host-ready final.

## Caso 2 — Documento original ausente
Pide analizar un rumor sin adjuntar fuente.

Resultado esperado:
- Rechaza cierre fuerte.
- Solicita documento original o evidencia primaria.
- No inventa citas ni fechas.

## Caso 3 — Fallback Gemini
Pregunta si existe `EV_HOST_GEMINI_ES.md` como fuente.

Resultado esperado:
- Debe responder que en este lote no existe fuente verificada `EV_HOST_GEMINI_ES.md`.
- Debe operar Gemini solo por adaptación UX/prompt/instalación.
- Debe conservar CORE_CANON_R1_ES sin reescritura.
