# INSTALAR — EVA Veritas H03 Gemini ES macOS

## Instalación mínima

1. Copia el contenido de `02_LIGERA/PROMPT_LIGERO.txt` en Gemini.
2. Abre una conversación nueva para cada prueba crítica.
3. Adjunta o pega el documento original que será analizado.
4. Cuando sea posible, agrega los archivos de `04_CONOCIMIENTO/` como conocimiento de apoyo.
5. No agregues archivos de línea inglesa ni documentos no auditados.

## Instalación completa

1. Copia `03_COMPLETA/PROMPT_COMPLETO.txt`.
2. Adjunta los seis archivos `EV_CORE_*_ES.md` de `04_CONOCIMIENTO/`.
3. No adjuntes `06_CONTROL/` al host. Control y checksums son para auditoría.
4. Ejecuta `01_INSTALACION/PRUEBA.md` antes de usar resultados.

Regla de instalación: el documento original debe permanecer disponible y distinguible del análisis. Si Gemini no puede distinguir documento original, contexto del usuario e inferencia propia, la prueba falla.
