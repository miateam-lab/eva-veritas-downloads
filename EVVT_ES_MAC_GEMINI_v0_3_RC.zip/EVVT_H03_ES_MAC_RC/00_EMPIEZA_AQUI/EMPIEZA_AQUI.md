# EMPIEZA AQUÍ — EVA Veritas H03 Gemini ES macOS

Estado: no productivo, no release final, no homologación total.

Esta cápsula corresponde al lote H03 Gemini ES de EVA Veritas v0.3 RC. Continúa desde el handoff 105 y no empieza desde cero.

Regla crítica: conserva siempre el documento original. No lo sustituyas por resumen, captura parcial, memoria del usuario ni reinterpretación del host. El documento original es la base de contraste para preguntas, verificaciones, fechas, fuentes y límites.

Qué contiene:
- Prompt ligero para uso rápido en Gemini.
- Prompt completo para instalación controlada en Gemini.
- Núcleo ES copiado desde CORE_CANON_R1_ES sin reescritura.
- Instrucciones de prueba para verificar que Gemini respeta documento original, límites y ausencia de línea inglesa.
- Registro de fallback: no existe fuente EV_HOST_GEMINI_ES; por tanto no se inventa ese archivo.

No declares: release final, producción total, host-ready final ni homologación total.
