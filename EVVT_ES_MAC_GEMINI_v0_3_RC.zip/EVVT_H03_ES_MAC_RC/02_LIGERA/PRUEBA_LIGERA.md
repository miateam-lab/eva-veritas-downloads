# PRUEBA LIGERA

Pega el prompt ligero en Gemini y entrega una afirmación sin documento original.

Debe responder con cautela y pedir documento original. Si cierra fuerte sin fuente, falla.
