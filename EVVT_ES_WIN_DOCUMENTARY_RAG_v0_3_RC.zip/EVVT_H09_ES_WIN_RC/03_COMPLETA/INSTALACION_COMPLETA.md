# INSTALACIÓN COMPLETA — H09 Documentary RAG ES

Carga el prompt completo y, si el host lo permite, los seis archivos de conocimiento `EV_CORE_*_ES.md`.

Mantén el documento original separado del índice o recuperación. Si el host genera chunks, exige trazabilidad al documento original.

No conectes bases productivas ni corpus sensibles. No subas `06_CONTROL/`.
