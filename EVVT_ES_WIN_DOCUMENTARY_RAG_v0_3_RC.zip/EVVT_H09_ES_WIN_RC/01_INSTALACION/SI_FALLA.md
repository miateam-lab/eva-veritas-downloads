# SI FALLA

Si el host mezcla documento original con chunks o inferencias:
1. Reinicia la sesión.
2. Vuelve a cargar solo el prompt y el documento original.
3. Pide separación explícita entre documento original, recuperación RAG e inferencia.
4. Si sigue fallando, no uses el resultado como cierre fuerte.

El fallo de separación documental bloquea conclusiones fuertes.
