# NO SUBIR

No subas:
- `06_CONTROL/`
- manifests o checksums al host de uso común
- documentos privados sin autorización
- corpus sensibles
- bases vectoriales productivas
- claves, tokens, credenciales o endpoints privados
- archivos de línea inglesa

Control e integridad se conservan para auditoría, no para operación común.
