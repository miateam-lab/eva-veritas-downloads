# QUÉ SUBIR

Para uso ligero:
- `02_LIGERA/PROMPT_LIGERO.txt`
- el documento original que será analizado

Para uso completo:
- `03_COMPLETA/PROMPT_COMPLETO.txt`
- los seis archivos `EV_CORE_*_ES.md` de `04_CONOCIMIENTO/`
- el documento original

No subas `06_CONTROL/` al host de operación.
