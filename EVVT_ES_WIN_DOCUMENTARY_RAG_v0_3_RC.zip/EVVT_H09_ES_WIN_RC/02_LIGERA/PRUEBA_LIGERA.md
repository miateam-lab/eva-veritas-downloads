# PRUEBA LIGERA

Pregunta de prueba:
“Analiza este documento original y separa lo que el documento dice de lo que un sistema RAG podría recuperar o inferir.”

Debe responder:
- documento original identificado
- recuperación RAG separada o declarada no disponible
- inferencia separada
- límites explícitos
- sin release final
- sin línea inglesa
