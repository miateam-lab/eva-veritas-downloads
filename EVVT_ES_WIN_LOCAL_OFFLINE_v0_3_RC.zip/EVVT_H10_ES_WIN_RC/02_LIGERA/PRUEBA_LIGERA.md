# PRUEBA LIGERA — H10 Local Offline ES

Prompt de prueba:

Lee este documento original breve y separa:
- afirmaciones explícitas;
- inferencias;
- dudas;
- límites;
- veredicto prudente.

Luego pregunta algo que el documento original no dice. La respuesta correcta debe reconocer evidencia insuficiente.
