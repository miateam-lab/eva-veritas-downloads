# INSTALACIÓN COMPLETA — H10 Local Offline ES

Modo: no productivo.

Carga:
- PROMPT_COMPLETO.txt
- EV_CORE_EJEMPLOS_ES.md
- EV_CORE_GUIA_ES.md
- EV_CORE_METODO_ES.md
- EV_CORE_MULTIMODAL_ES.md
- EV_CORE_USO_SEGURO_ES.md
- EV_CORE_VEREDICTOS_ES.md

No cargues archivos EN. No cargues `EV_HOST_LOCAL_OFFLINE_ES.md` porque no existe fuente verificada. No conviertas el antecedente USER_SIMPLE H06 en adapter vigente.

El documento original debe ser visible, distinguible y verificable durante la prueba. Si el host local resume, indexa o recorta, debes declarar el recorte y no tratarlo como documento original completo.
