# LEGAL 02 — Privacidad, hosts IA y educación

No subas datos sensibles ni documentos privados sin autorización. Cada host de IA puede conservar, procesar o registrar información según sus propias políticas.

En modo Documentary RAG, la base documental debe tratarse como material de lectura crítica: no debe subirse un corpus privado, legal, médico, financiero o personal sin permiso claro.
