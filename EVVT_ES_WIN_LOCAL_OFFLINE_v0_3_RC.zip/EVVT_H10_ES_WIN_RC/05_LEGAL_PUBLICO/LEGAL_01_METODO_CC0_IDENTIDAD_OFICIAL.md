# LEGAL 01 — Método CC0 e identidad oficial

EVA Veritas se distribuye como método abierto para lectura crítica y conciencia informativa. La identidad oficial, nombre, marca, logo y versiones oficiales pertenecen a ARCorp/MIA según el marco documental del proyecto.

El método puede estudiarse, copiarse, adaptarse y compartirse. Esta cápsula no declara release final ni homologación total.
