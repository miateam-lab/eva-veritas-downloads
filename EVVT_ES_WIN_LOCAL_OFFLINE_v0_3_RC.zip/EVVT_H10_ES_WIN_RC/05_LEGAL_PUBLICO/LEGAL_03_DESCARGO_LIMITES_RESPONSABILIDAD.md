# LEGAL 03 — Descargo de límites y responsabilidad

EVA Veritas no sustituye asesoría legal, médica, financiera, periodística profesional ni verificación oficial. Sus resultados son apoyo crítico, no verdad absoluta.

Si la evidencia documental es insuficiente, debe declararse insuficiente. El documento original conserva prioridad frente a resúmenes, embeddings, índices o respuestas generadas.
