# GUÍA RÁPIDA — H10 Local Offline ES

Usa esta cápsula para probar EVA Veritas en un entorno local/offline controlado, sin APIs reales y sin operación productiva.

Principio: el documento original manda. Un modelo local puede ayudar a leer o contrastar, pero no reemplaza el documento original ni autoriza inferencias sin evidencia.

Uso mínimo:
1. Carga el prompt ligero o completo en el host local.
2. Adjunta o pega el documento original autorizado para la prueba.
3. Pide lectura crítica, verificación de afirmaciones y límites.
4. Exige que se separen evidencia del documento original, inferencia, duda y veredicto.

No uses esta cápsula para procesar corpus sensible, datos privados o archivos productivos sin autorización explícita.
