# EMPIEZA AQUÍ — EVA Veritas H10 Local Offline ES Windows

Estado: no productivo, no release final, no homologación total.

Esta cápsula corresponde al lote H10 Local Offline ES de EVA Veritas v0.3 RC. Continúa desde QA_103R16_BATCH_H09_ES_DOCUMENTARY_RAG_EVA_VERITAS_v0_3_RC, sin empezar de cero.

Regla crítica: conserva siempre el documento original. En un entorno Local Offline, un modelo local, archivo copiado, cache, exportación, resumen local, memoria de sesión o respuesta offline no sustituye el documento original. El documento original es la base de contraste para preguntas, verificaciones, fechas, fuentes y límites.

Qué contiene:
- Prompt ligero para uso conceptual en un host Local Offline.
- Prompt completo para instalación controlada en entorno local/no productivo.
- Núcleo ES copiado desde CORE_CANON_R1_ES sin reescritura.
- Instrucciones de prueba para verificar documento original, límites, trazabilidad, ausencia de línea inglesa y ausencia de operación local productiva no autorizada.
- Registro de fallback: no existe fuente `EV_HOST_LOCAL_OFFLINE_ES`; por tanto no se inventa ese archivo.
- Registro COCO: USER_SIMPLE H06 LLM Local Offline es antecedente UX/local controlado, no core ni adapter vigente.

No declares: release final, producción total, host-ready final ni homologación total.
