# QUÉ SUBIR — H10 Local Offline ES

Para prueba controlada puedes subir o pegar:

- Un documento original breve y autorizado.
- Una afirmación pública para contraste.
- Un ejemplo sintético de noticia, rumor o comunicado.
- Los archivos `EV_CORE_*_ES.md` copiados desde CORE_CANON_R1_ES, si el host local permite conocimiento adjunto.

El documento original debe permanecer distinguible de notas, resúmenes, memoria local, outputs del modelo o contexto del usuario.
