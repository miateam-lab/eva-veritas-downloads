# NO SUBIR — H10 Local Offline ES

No subas ni proceses:

- Documentos sensibles, privados o confidenciales.
- Corpus productivos completos.
- Datos personales no autorizados.
- Pesos de modelos, llaves, tokens, credenciales, dumps, logs internos o secretos.
- Archivos EN para expansión inglesa.

No uses esta cápsula para afirmar que hay release final o producción total.
