# SI FALLA — H10 Local Offline ES

Si el host local no conserva el documento original o mezcla evidencia con inferencia:

1. Detén la prueba.
2. Declara evidencia insuficiente.
3. Vuelve al documento original.
4. No uses outputs anteriores como fuente primaria.
5. Registra el fallo para QA_103R17.

No repares reescribiendo el core. No inventes `EV_HOST_LOCAL_OFFLINE_ES.md`.
