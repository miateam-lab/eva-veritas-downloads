# EMPIEZA AQUÍ — EVA Veritas H09 Documentary RAG ES macOS

Estado: no productivo, no release final, no homologación total.

Esta cápsula corresponde al lote H09 Documentary RAG ES de EVA Veritas v0.3 RC. Continúa desde QA_103R15 H08 API Agents ES, sin empezar de cero.

Regla crítica: conserva siempre el documento original. En un entorno Documentary RAG, un índice, embedding, chunk, resumen, búsqueda semántica o respuesta recuperada no sustituye el documento original. El documento original es la base de contraste para preguntas, verificaciones, fechas, fuentes y límites.

Qué contiene:
- Prompt ligero para uso conceptual en Documentary RAG.
- Prompt completo para instalación controlada en sandbox documental/RAG.
- Núcleo ES copiado desde CORE_CANON_R1_ES sin reescritura.
- Instrucciones de prueba para verificar documento original, límites, trazabilidad, ausencia de línea inglesa y ausencia de corpus productivo no autorizado.
- Registro de fallback: no existe fuente `EV_HOST_DOCUMENTARY_RAG_ES`; por tanto no se inventa ese archivo.
- Registro COCO: USER_SIMPLE H08 RAG Documental es antecedente UX/RAG controlado, no core ni adapter vigente.

No declares: release final, producción total, host-ready final ni homologación total.
