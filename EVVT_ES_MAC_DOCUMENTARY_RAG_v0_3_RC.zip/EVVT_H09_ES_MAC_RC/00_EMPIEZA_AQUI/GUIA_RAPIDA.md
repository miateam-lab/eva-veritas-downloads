# GUÍA RÁPIDA — H09 Documentary RAG ES macOS

Uso previsto: análisis crítico de un documento original con apoyo RAG documental en modo no productivo.

Tres reglas:
1. El documento original manda sobre chunks, índices, embeddings, resúmenes y respuestas recuperadas.
2. Si una respuesta RAG no puede apuntar al documento original, el resultado queda débil o insuficiente.
3. No uses corpus reales sensibles ni bases productivas. Esta cápsula es sandbox documental.

COCO aplica: copia, cobertura y coherencia deben conservarse antes de cualquier QA.
