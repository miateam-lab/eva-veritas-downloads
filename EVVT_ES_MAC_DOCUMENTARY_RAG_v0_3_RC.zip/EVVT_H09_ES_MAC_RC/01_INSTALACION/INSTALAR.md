# INSTALAR — EVA Veritas H09 Documentary RAG ES macOS

## Instalación mínima

1. Copia el contenido de `02_LIGERA/PROMPT_LIGERO.txt` en el host documental/RAG.
2. Usa solo sandbox conceptual. No conectes repositorios productivos, bases privadas, documentos sensibles ni índices reales no autorizados.
3. Adjunta o pega el documento original que será analizado.
4. Pide al host que separe documento original, chunks recuperados, contexto externo, contexto del usuario, inferencias y límites.
5. No agregues archivos de línea inglesa ni documentos no auditados.

## Instalación completa

1. Copia `03_COMPLETA/PROMPT_COMPLETO.txt`.
2. Adjunta los seis archivos `EV_CORE_*_ES.md` de `04_CONOCIMIENTO/` si el host lo permite.
3. No adjuntes `06_CONTROL/` al host. Control y checksums son para auditoría.
4. Mantén el RAG como sandbox: sin indexar datos sensibles, sin conectar repositorios reales y sin declarar que un chunk reemplaza la fuente primaria.
5. Ejecuta `01_INSTALACION/PRUEBA.md` antes de usar resultados.

Regla de instalación: el documento original debe permanecer disponible y distinguible del análisis, del índice, del chunk, del embedding, del resumen y de cualquier salida generada.
