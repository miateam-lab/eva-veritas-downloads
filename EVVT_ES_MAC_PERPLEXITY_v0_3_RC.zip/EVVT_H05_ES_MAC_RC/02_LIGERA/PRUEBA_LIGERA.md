# PRUEBA LIGERA

Pega el prompt ligero en Perplexity y entrega una afirmación sin documento original.

Debe responder con cautela, pedir documento original y distinguir cualquier resultado web como contexto secundario. Si cierra fuerte sin fuente primaria, falla.
