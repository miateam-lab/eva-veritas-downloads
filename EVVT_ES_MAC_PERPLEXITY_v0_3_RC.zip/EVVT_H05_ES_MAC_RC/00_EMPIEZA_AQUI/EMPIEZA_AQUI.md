# EMPIEZA AQUÍ — EVA Veritas H05 Perplexity ES macOS

Estado: no productivo, no release final, no homologación total.

Esta cápsula corresponde al lote H05 Perplexity ES de EVA Veritas v0.3 RC. Continúa desde QA_103R11 H04 Claude ES, sin empezar de cero.

Regla crítica: conserva siempre el documento original. En Perplexity, una respuesta con enlaces o citas no sustituye el documento original. El documento original es la base de contraste para preguntas, verificaciones, fechas, fuentes y límites.

Qué contiene:
- Prompt ligero para uso rápido en Perplexity.
- Prompt completo para instalación controlada en Perplexity.
- Núcleo ES copiado desde CORE_CANON_R1_ES sin reescritura.
- Instrucciones de prueba para verificar búsqueda, citas, documento original, límites y ausencia de línea inglesa.
- Registro de fallback: no existe fuente `EV_HOST_PERPLEXITY_ES`; por tanto no se inventa ese archivo.
- Uso de `USER_SIMPLE v0.1 H11 Perplexity` solo como antecedente UX, no como core ni fuente host vigente.

No declares: release final, producción total, host-ready final ni homologación total.
