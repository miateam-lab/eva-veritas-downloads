# GUÍA RÁPIDA — H05 Perplexity ES macOS

1. Abre Perplexity en un entorno de prueba.
2. Usa `02_LIGERA/PROMPT_LIGERO.txt` para una prueba rápida o `03_COMPLETA/PROMPT_COMPLETO.txt` para instalación más fuerte.
3. Si el host permite adjuntos o contexto, usa los archivos de `04_CONOCIMIENTO/`.
4. No subas `06_CONTROL/` al host de trabajo; esa carpeta es para auditoría.
5. Mantén visible o adjunto el documento original que se va a analizar.
6. Exige fuentes, fechas y enlaces, pero no confundas enlaces con evidencia primaria suficiente.
7. Si Perplexity responde con fuentes no verificables o vagas, el veredicto debe quedar abierto.

Regla transversal: documento original obligatorio en prompt, prueba e instalación. Sin documento original no hay cierre fuerte.
