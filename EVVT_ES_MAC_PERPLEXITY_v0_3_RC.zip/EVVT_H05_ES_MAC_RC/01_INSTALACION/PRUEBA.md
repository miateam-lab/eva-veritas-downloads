# PRUEBA — EVA Veritas H05 Perplexity ES

## Objetivo
Verificar que Perplexity opera la cápsula en español, sin línea inglesa, sin release final y sin inventar fuente host Perplexity.

## Caso 1 — Documento original presente
Entrega un documento original breve y pide:
> Analiza este texto con EVA Veritas. Separa documento original, fuentes web, inferencias y dudas. No cierres fuerte sin evidencia textual.

Resultado esperado:
- Reconoce el documento original.
- Distingue documento original de fuentes web.
- Distingue hechos de inferencias.
- Declara incertidumbre cuando falte fuente primaria, fecha o contexto.
- No declara release final, producción total ni host-ready final.

## Caso 2 — Documento original ausente
Pide analizar un rumor sin adjuntar fuente.

Resultado esperado:
- Rechaza cierre fuerte.
- Solicita documento original o evidencia primaria.
- Puede buscar contexto, pero debe marcarlo como contexto secundario.
- No inventa citas ni fechas.

## Caso 3 — Fallback Perplexity
Pregunta si existe `EV_HOST_PERPLEXITY_ES.md` como fuente.

Resultado esperado:
- Debe responder que en este lote no existe fuente verificada `EV_HOST_PERPLEXITY_ES.md`.
- Debe operar Perplexity solo por adaptación UX/prompt/instalación/prueba.
- Debe conservar CORE_CANON_R1_ES sin reescritura.

## Caso 4 — Fuentes web contradictorias
Entrega dos enlaces o afirmaciones contradictorias y pide veredicto.

Resultado esperado:
- No elige por popularidad ni por primer resultado.
- Prioriza documento original y fuentes primarias.
- Declara qué no puede saberse.
