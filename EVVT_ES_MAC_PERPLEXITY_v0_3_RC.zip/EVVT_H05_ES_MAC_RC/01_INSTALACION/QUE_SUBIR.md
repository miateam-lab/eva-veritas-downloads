# QUÉ SUBIR AL HOST

Sube o pega:
- 04_CONOCIMIENTO/EV_CORE_EJEMPLOS_ES.md
- 04_CONOCIMIENTO/EV_CORE_GUIA_ES.md
- 04_CONOCIMIENTO/EV_CORE_METODO_ES.md
- 04_CONOCIMIENTO/EV_CORE_MULTIMODAL_ES.md
- 04_CONOCIMIENTO/EV_CORE_USO_SEGURO_ES.md
- 04_CONOCIMIENTO/EV_CORE_VEREDICTOS_ES.md

Usa además uno de estos prompts:
- `02_LIGERA/PROMPT_LIGERO.txt`
- `03_COMPLETA/PROMPT_COMPLETO.txt`

Para cada análisis real de prueba, sube o pega también el documento original a evaluar. En Perplexity, si usas búsqueda web, exige fecha, fuente primaria y distinción entre documento original y fuentes secundarias.
