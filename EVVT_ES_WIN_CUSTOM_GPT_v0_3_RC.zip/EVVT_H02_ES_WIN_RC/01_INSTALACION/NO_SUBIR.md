# NO SUBIR AL HOST

No subas a Custom GPT:
- `06_CONTROL/`
- `CHECKSUMS.sha256.json`
- `MANIFEST.json`
- `CUSTOM_GPT_SOURCE_AUDIT_102R10.json`
- archivos de línea inglesa
- documentos privados o sensibles sin autorización
- material que no pueda verificarse contra el documento original

Esta cápsula no contiene `EV_HOST_CUSTOM_GPT_ES.md` porque no se encontró fuente verificada. Crear ese archivo desde memoria rompería la regla no-inventar.


## Fallback de host
No se encontró fuente `EV_HOST_CUSTOM_GPT_ES.md`; por tanto Custom GPT se adapta solo en UX, prompt, instalación y prueba. No se inventa archivo host.
