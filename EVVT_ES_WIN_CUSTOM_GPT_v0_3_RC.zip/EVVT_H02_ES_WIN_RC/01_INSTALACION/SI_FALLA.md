# SI FALLA

Falla bloqueante si Custom GPT:
- inventa `EV_HOST_CUSTOM_GPT_ES.md`;
- declara release final;
- usa línea inglesa;
- resume el core como sustituto del core;
- analiza sin documento original y aun así cierra fuerte;
- mezcla documento original, opinión del usuario e inferencia propia sin distinguir capas.

Ruta de reparación:
1. Detener uso del lote.
2. Registrar el fallo en QA_103R10.
3. Reparar solo la capa afectada si no toca EV_CORE.
4. No reescribir CORE_CANON_R1_ES.


## Fallback de host
No se encontró fuente `EV_HOST_CUSTOM_GPT_ES.md`; por tanto Custom GPT se adapta solo en UX, prompt, instalación y prueba. No se inventa archivo host.
