# Legal 03 — Descargo y límites de responsabilidad

EVA Veritas ayuda a leer críticamente información. No produce verdad absoluta, no reemplaza asesoría profesional ni valida hechos sin fuentes suficientes.

No hay producción total, homologación total ni host-ready final.
