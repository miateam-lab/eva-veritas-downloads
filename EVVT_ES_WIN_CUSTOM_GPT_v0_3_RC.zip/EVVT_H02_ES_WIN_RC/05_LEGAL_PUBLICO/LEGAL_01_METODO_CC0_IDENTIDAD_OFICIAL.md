# Legal 01 — Método CC0 e identidad oficial

El método operativo puede estudiarse, copiarse y adaptarse como semilla abierta, salvo elementos de identidad oficial, marca, logo y versiones oficiales de ARCorp/MIA.

Este paquete no declara release final.
