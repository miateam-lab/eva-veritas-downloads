# Legal 02 — Privacidad, hosts de IA y educación

No subas datos sensibles, documentos privados, credenciales, historiales personales ni corpus confidenciales al host. Usa copias de prueba o textos públicos.

Cada host puede tener políticas propias de datos. Este paquete no sustituye esas políticas.
