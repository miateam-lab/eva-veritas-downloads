# PRUEBA LIGERA

Pega el prompt ligero en Custom GPT y entrega una afirmación sin documento original.

Debe responder con cautela y pedir documento original. Si cierra fuerte sin fuente, falla.


## Nota de recuperación 112R1
Este artefacto fue recuperado/regenerado bajo SOURCE_FIRST desde `CORE_CANON_R1_ES`. No usa 102R6 ni USER_SIMPLE como core. El documento original sigue siendo obligatorio.


## Fallback de host
No se encontró fuente `EV_HOST_CUSTOM_GPT_ES.md`; por tanto Custom GPT se adapta solo en UX, prompt, instalación y prueba. No se inventa archivo host.
