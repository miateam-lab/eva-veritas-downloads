# EMPIEZA AQUÍ — EVA Veritas H02 Custom GPT ES Windows

Estado: no productivo, no release final, no homologación total.

Esta cápsula corresponde al lote H02 Custom GPT ES de EVA Veritas v0.3 RC. Continúa desde el handoff 105 y no empieza desde cero.

Regla crítica: conserva siempre el documento original. No lo sustituyas por resumen, captura parcial, memoria del usuario ni reinterpretación del host. El documento original es la base de contraste para preguntas, verificaciones, fechas, fuentes y límites.

Qué contiene:
- Prompt ligero para uso rápido en Custom GPT.
- Prompt completo para instalación controlada en Custom GPT.
- Núcleo ES copiado desde CORE_CANON_R1_ES sin reescritura.
- Instrucciones de prueba para verificar que Custom GPT respeta documento original, límites y ausencia de línea inglesa.
- Registro de fallback: no existe fuente EV_HOST_CUSTOM_GPT_ES; por tanto no se inventa ese archivo.

No declares: release final, producción total, host-ready final ni homologación total.


## Nota de recuperación 112R1
Este artefacto fue recuperado/regenerado bajo SOURCE_FIRST desde `CORE_CANON_R1_ES`. No usa 102R6 ni USER_SIMPLE como core. El documento original sigue siendo obligatorio.
