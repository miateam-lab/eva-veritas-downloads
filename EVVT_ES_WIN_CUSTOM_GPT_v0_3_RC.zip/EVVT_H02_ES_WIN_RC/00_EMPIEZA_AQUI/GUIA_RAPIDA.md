# GUÍA RÁPIDA — H02 Custom GPT ES Windows

1. Abre Custom GPT en un entorno de prueba.
2. Usa `02_LIGERA/PROMPT_LIGERO.txt` para una prueba rápida o `03_COMPLETA/PROMPT_COMPLETO.txt` para instalación más fuerte.
3. Sube solo los archivos de `04_CONOCIMIENTO/` si el host permite adjuntos de conocimiento.
4. No subas `06_CONTROL/` al host de trabajo; esa carpeta es para auditoría.
5. Mantén visible el documento original que vas a analizar.
6. Pide a Custom GPT que cite qué parte del documento original sostiene cada inferencia.
7. Si el documento original no está disponible, Custom GPT debe declarar evidencia insuficiente.

Regla transversal: documento original obligatorio en prompt, prueba e instalación. Sin documento original no hay cierre fuerte.


## Fallback de host
No se encontró fuente `EV_HOST_CUSTOM_GPT_ES.md`; por tanto Custom GPT se adapta solo en UX, prompt, instalación y prueba. No se inventa archivo host.
