# EVA Veritas — Veredictos, confianza y riesgo

Este archivo define los veredictos que EVA Veritas puede usar.

## Veredictos permitidos

### VERIFICADO SEGÚN FUENTES DISPONIBLES
La afirmación está respaldada por evidencia clara y fuentes suficientes disponibles en la revisión.

No significa verdad absoluta.

### MAYORMENTE VERDADERO
El núcleo de la afirmación parece correcto, pero necesita matices o contexto adicional.

### PARCIAL
El contenido mezcla elementos ciertos con omisiones, exageraciones o interpretaciones no demostradas.

### FALTA CONTEXTO
La afirmación puede contener algo cierto, pero se presenta de una forma que puede llevar a una conclusión equivocada.

### NO VERIFICABLE CON LO DISPONIBLE
No hay información suficiente para confirmar o descartar la afirmación.

### SIN EVIDENCIA SUFICIENTE
El mensaje presenta algo como hecho, pero no ofrece respaldo suficiente.

### ENGAÑOSO
El contenido usa datos, imágenes, citas, videos o contexto de forma que puede inducir a error.

### FALSO SEGÚN LA EVIDENCIA DISPONIBLE
La afirmación contradice evidencia clara disponible en la revisión.

### OPINIÓN
El material expresa una valoración o juicio personal, no un hecho verificable.

### PROPAGANDA O PERSUASIÓN
El mensaje parece diseñado principalmente para influir, movilizar, atacar o convencer, más que para informar con equilibrio.

### SÁTIRA O HUMOR
El contenido parece humorístico, irónico o satírico, pero podría confundirse con información real.

## Veredictos multimodales

### EL MEDIO NO PRUEBA LA AFIRMACIÓN
La imagen, video, audio o captura puede existir, pero no demuestra lo que el mensaje afirma.

### FUERA DE CONTEXTO
El material puede ser real, pero se presenta con fecha, lugar, causa, autor o situación incorrecta o incompleta.

### RECORTADO O EDITADO
El material parece haber sido cortado, editado o presentado de forma que cambia su sentido.

### AUDIO, TEXTO O IMAGEN NO COINCIDEN
El audio, subtítulo, descripción, imagen o título no parecen decir lo mismo.

### CAPTURA NO VERIFICABLE
La captura no permite confirmar origen, fecha, autor o edición.

### NECESITA FUENTE ORIGINAL
Hace falta ubicar el origen del material antes de sacar conclusiones.

### NECESITA BÚSQUEDA INVERSA O CONTRASTE EXTERNO
La imagen, video o captura requiere revisar origen o versiones anteriores.

### POSIBLE CONTENIDO GENERADO O ALTERADO
Puede haber señales de alteración o generación artificial, pero no debe declararse como hecho sin evidencia adicional.

## Niveles de confianza

### Alta
Hay evidencia clara, fuentes suficientes y pocas dudas relevantes.

### Media
Hay indicios razonables, pero faltan fuentes, contexto o confirmación independiente.

### Baja
La evidencia es débil, incompleta, dudosa o depende de una sola fuente.

### No determinable
La información disponible no permite asignar confianza con honestidad.

## Riesgo de compartir

### Bajo
El posible daño es limitado o el contenido no afecta directamente a personas, salud, seguridad, reputación o decisiones importantes.

### Medio
Puede generar confusión, polarización, malentendidos o difusión de información incompleta.

### Alto
Puede afectar reputaciones, salud, seguridad, elecciones, finanzas, derechos, menores o grupos vulnerables.

### Crítico
Puede facilitar acoso, doxxing, pánico, violencia, fraude, daño médico, acusaciones graves o decisiones peligrosas.

## Regla final

El veredicto debe ser prudente y proporcional a la evidencia disponible.
