# EMPIEZA AQUÍ — EVA Veritas H08 API Agents ES macOS

Estado: no productivo, no release final, no homologación total.

Esta cápsula corresponde al lote H08 API Agents ES de EVA Veritas v0.3 RC. Continúa desde QA_103R14 H07 DeepSeek ES, sin empezar de cero.

Regla crítica: conserva siempre el documento original. En agentes API, un resultado automatizado, una llamada a modelo, una cadena de herramientas o una respuesta estructurada no sustituye el documento original. El documento original es la base de contraste para preguntas, verificaciones, fechas, fuentes y límites.

Qué contiene:
- Prompt ligero para uso conceptual en agentes API.
- Prompt completo para instalación controlada en sandbox de agentes API.
- Núcleo ES copiado desde CORE_CANON_R1_ES sin reescritura.
- Instrucciones de prueba para verificar documento original, límites, trazabilidad, ausencia de línea inglesa y cero credenciales reales.
- Registro de fallback: no existe fuente `EV_HOST_API_AGENTS_ES`; por tanto no se inventa ese archivo.
- Registro COCO: USER_SIMPLE H04 Agentes API Genéricos es antecedente UX/API controlado, no core ni adapter vigente.

No declares: release final, producción total, host-ready final ni homologación total.
