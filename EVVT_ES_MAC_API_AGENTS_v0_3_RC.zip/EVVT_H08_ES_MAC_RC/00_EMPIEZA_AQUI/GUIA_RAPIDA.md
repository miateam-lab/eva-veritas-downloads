# GUÍA RÁPIDA — EVA Veritas H08 API Agents ES macOS

Uso previsto: probar EVA Veritas en un entorno conceptual o sandbox de agentes API, sin claves reales, sin datos sensibles y sin acciones productivas.

Pasos:
1. Abre un entorno de prueba aislado o una conversación que simule el agente.
2. Pega el prompt ligero o completo.
3. Aporta el documento original que será analizado.
4. Exige que el agente separe documento original, contexto externo, inferencia y duda.
5. No permitas que una salida JSON, una herramienta o una llamada API reemplace el documento original.

Si falta el documento original, el resultado debe ser evidencia insuficiente. Si el agente propone ejecutar acciones reales, la prueba falla.
