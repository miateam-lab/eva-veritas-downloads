# INSTALACIÓN COMPLETA — EVA Veritas H08 API Agents ES macOS

La instalación completa usa el prompt completo y los seis archivos core ES.

Mantén:
- SOURCE_FIRST.
- CORE_CANON_R1_ES sin reescritura.
- Documento original como base.
- COCO_GATE activo.
- Sandbox API sin credenciales reales.

No convertir este paquete en release final.
