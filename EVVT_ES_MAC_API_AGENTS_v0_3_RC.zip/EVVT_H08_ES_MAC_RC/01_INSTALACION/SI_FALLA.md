# SI FALLA — EVA Veritas H08 API Agents ES macOS

Si el host falla:

1. Detén la prueba.
2. Registra la respuesta problemática.
3. Identifica si falló por documento original, credenciales, acción externa, mezcla de capas, EN, release falso o reducción del core.
4. No repares reescribiendo el core.
5. No inventes `EV_HOST_API_AGENTS_ES.md`.
6. Devuelve el caso a QA_103R15.

La reparación debe ser documental y trazable, no una simplificación improvisada.
