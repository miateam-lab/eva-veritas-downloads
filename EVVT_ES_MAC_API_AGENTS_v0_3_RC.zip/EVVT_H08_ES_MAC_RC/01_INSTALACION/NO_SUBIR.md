# NO SUBIR — EVA Veritas H08 API Agents ES macOS

No subir ni pegar:

- Credenciales reales de API.
- Tokens, llaves privadas, secretos, cookies o variables de entorno.
- Datos personales sensibles.
- Archivos de control `06_CONTROL/` como si fueran conocimiento operativo.
- Archivos EN o traducciones no autorizadas.
- USER_SIMPLE v0.1 como si fuera core actual.

El documento original sí puede aportarse para la prueba, siempre que el usuario tenga derecho a usarlo y que no contenga datos sensibles innecesarios.
