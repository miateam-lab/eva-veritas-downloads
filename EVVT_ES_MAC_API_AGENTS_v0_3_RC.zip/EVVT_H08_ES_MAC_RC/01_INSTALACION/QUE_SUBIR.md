# QUÉ SUBIR — EVA Veritas H08 API Agents ES macOS

Para uso ligero:
- `02_LIGERA/PROMPT_LIGERO.txt`
- Documento original que será analizado.

Para uso completo:
- `03_COMPLETA/PROMPT_COMPLETO.txt`
- Los seis archivos `EV_CORE_*_ES.md` de `04_CONOCIMIENTO/`.
- Documento original que será analizado.

No subir `06_CONTROL/` como conocimiento operativo. Es evidencia para auditoría.
