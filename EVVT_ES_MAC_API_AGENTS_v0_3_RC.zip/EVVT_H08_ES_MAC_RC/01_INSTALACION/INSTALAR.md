# INSTALAR — EVA Veritas H08 API Agents ES macOS

## Instalación mínima

1. Copia el contenido de `02_LIGERA/PROMPT_LIGERO.txt` en el host o simulador de agentes API.
2. Usa solo sandbox conceptual. No uses claves reales, endpoints productivos ni datos sensibles.
3. Adjunta o pega el documento original que será analizado.
4. Pide al agente que separe documento original, contexto externo, contexto del usuario, inferencias y límites.
5. No agregues archivos de línea inglesa ni documentos no auditados.

## Instalación completa

1. Copia `03_COMPLETA/PROMPT_COMPLETO.txt`.
2. Adjunta los seis archivos `EV_CORE_*_ES.md` de `04_CONOCIMIENTO/` si el host lo permite.
3. No adjuntes `06_CONTROL/` al host. Control y checksums son para auditoría.
4. Configura herramientas en modo simulado: sin credenciales reales, sin escritura externa, sin compras, sin envíos, sin scraping no autorizado y sin acciones irreversibles.
5. Ejecuta `01_INSTALACION/PRUEBA.md` antes de usar resultados.

Regla de instalación: el documento original debe permanecer disponible y distinguible del análisis, del contexto externo, de la inferencia y de cualquier salida generada por herramientas.
