# INSTALAR — H11 Newsroom ES (macOS)

Sube a tu entorno de trabajo los archivos de conocimiento `EV_CORE_*_ES.md`. No existe `EV_HOST_NEWSROOM_ES.md` como fuente canónica; por tanto, Newsroom vive solo en UX, prompt, instalación y prueba.

Antes de usar el flujo, confirma que el **documento original** está disponible o que se declara explícitamente su ausencia.
