# QUÉ SUBIR

Subir solo archivos `EV_CORE_*_ES.md` y, si el entorno lo permite, el documento original que será analizado.

No subir archivos de control si el host no los necesita. No subir paquetes EN.
