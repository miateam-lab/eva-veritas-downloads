# SI FALLA

Si el host produce conclusiones sin fuente, titulares sensacionalistas o reemplaza el documento original por un resumen, detén el flujo. Repite el prompt exigiendo evidencia, fecha, fuente y límites.
