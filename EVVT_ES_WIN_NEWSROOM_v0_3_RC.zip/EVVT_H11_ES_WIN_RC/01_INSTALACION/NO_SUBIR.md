# NO SUBIR

No subir:
- documentos sensibles o privados;
- fuentes protegidas sin permiso;
- credenciales;
- bases de datos editoriales reales;
- material de investigación no autorizado;
- versiones EN, porque EN sigue bloqueado.
