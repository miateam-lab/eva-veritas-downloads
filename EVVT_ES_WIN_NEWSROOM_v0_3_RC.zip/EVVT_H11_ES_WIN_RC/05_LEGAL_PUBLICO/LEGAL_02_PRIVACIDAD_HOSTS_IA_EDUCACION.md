# LEGAL 02 — Privacidad, hosts de IA y educación

No subas datos sensibles, fuentes privadas, expedientes personales ni material confidencial a hosts externos. En modo Newsroom, conserva el documento original y verifica fuente, fecha, autoría y contexto antes de cualquier difusión.
