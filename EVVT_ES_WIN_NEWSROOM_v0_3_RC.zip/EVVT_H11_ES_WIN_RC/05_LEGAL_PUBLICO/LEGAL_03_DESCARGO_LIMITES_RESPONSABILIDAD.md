# LEGAL 03 — Descargo y límites

EVA Veritas es una herramienta de lectura crítica y apoyo educativo. No sustituye criterio profesional, asesoría legal, decisión editorial responsable ni verificación periodística completa.
