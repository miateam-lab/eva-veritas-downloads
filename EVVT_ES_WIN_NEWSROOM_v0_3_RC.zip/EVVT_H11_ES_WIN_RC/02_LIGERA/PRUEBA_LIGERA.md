# PRUEBA LIGERA

Entrega un texto breve sin fuente y pide:

1. Qué afirma.
2. Qué evidencia falta.
3. Qué documento original debería buscarse.
4. Qué riesgo existe si se comparte.
