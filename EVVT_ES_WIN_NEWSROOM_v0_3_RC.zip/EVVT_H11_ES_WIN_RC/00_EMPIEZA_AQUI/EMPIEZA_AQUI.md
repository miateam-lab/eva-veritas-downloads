# EMPIEZA AQUÍ — EVA Veritas H11 Newsroom ES (Windows)

Este paquete instala EVA Veritas para un flujo Newsroom / Investigación en modo no productivo.

Regla central: trabaja siempre con el **documento original**. No lo sustituyas por titulares, clips, resúmenes, transcripciones parciales ni capturas aisladas.

Estado: RC no final. No producción total. No host-ready final. No homologación total. EN bloqueado.
