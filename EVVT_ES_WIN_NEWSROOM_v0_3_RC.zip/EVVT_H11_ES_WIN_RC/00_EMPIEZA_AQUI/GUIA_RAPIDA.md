# GUÍA RÁPIDA — H11 Newsroom ES

1. Abre el host o entorno de redacción asistida.
2. Usa `PROMPT_LIGERO.txt` o `PROMPT_COMPLETO.txt`.
3. Adjunta o cita el **documento original** cuando corresponda.
4. Pide lectura crítica, trazabilidad, verificación de fecha/fuente/contexto y detección de afirmaciones no soportadas.
5. No publiques automáticamente; Newsroom aquí es sandbox documental.
