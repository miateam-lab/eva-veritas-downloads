# INSTALACIÓN COMPLETA — H11 Newsroom ES

1. Instala los seis archivos `EV_CORE_*_ES.md`.
2. Usa `PROMPT_COMPLETO.txt`.
3. Mantén el documento original como pieza primaria.
4. Registra si falta fuente primaria.
5. No uses este paquete para producción editorial real sin revisión humana.
