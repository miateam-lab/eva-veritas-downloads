# LEGAL 03 — Descargo y límites

EVA Veritas es una herramienta de lectura crítica y apoyo educativo/documental. No sustituye criterio profesional, asesoría legal, verificación humana completa ni decisión editorial final.
