# LEGAL 02 — Privacidad y hosts de IA

No subas datos sensibles, expedientes privados, fuentes protegidas, credenciales ni material personal sin consentimiento. El modo Light no reduce la responsabilidad de proteger el documento original ni los datos del usuario.
