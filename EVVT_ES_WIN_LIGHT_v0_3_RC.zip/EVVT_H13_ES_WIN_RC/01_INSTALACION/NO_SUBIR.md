# NO SUBIR

No subir ni compartir:
- datos personales sensibles;
- expedientes privados;
- fuentes protegidas;
- credenciales;
- versiones EN, porque EN sigue bloqueado;
- archivos no necesarios para una prueba ligera.
