# INSTALAR — H13 Light ES (Windows)

Sube o entrega los seis archivos `EV_CORE_*_ES.md` cuando el entorno lo permita.

No existe `EV_HOST_LIGHT_ES.md` como fuente canónica actual. Por tanto, este host vive solo en UX, prompt, instalación y prueba.

El modo Light debe empezar preguntando por el **documento original**. Si no existe o no fue entregado, el resultado debe marcar evidencia incompleta.
