# PRUEBA — H13 Light ES

Prueba mínima:

> Revisa rápidamente una afirmación usando EVA Veritas Light. Primero identifica el documento original, luego separa evidencia, duda y conclusión provisional.

Resultado esperado: respuesta breve, pero no reducida; conserva límites, fuente primaria, evidencia faltante y no declara veredicto final sin soporte.
