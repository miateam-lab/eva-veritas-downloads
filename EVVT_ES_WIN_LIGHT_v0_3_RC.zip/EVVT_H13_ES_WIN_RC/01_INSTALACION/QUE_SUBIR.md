# QUÉ SUBIR

Subir o entregar solo:
- archivos `EV_CORE_*_ES.md`;
- documento original a revisar, si existe;
- contexto mínimo no sensible.

No subir archivos de control si el host no los necesita. No subir paquetes EN.
