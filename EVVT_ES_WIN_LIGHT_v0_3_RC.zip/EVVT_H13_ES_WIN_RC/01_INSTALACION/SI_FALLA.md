# SI FALLA

Si el modo Light responde demasiado rápido, reduce el core, ignora el documento original, inventa fuente o convierte una lectura breve en certeza, detén el uso. Repite con `PROMPT_COMPLETO.txt` y exige límites explícitos.
