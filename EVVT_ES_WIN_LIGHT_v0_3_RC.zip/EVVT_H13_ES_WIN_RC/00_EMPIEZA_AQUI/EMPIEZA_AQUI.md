# EMPIEZA AQUÍ — EVA Veritas H13 Light ES (Windows)

Este paquete instala EVA Veritas en modo **Light** para uso rápido y controlado.

Advertencia central: **Light no significa core reducido**. El modo Light simplifica la experiencia de uso, pero conserva los seis archivos `EV_CORE_*_ES.md` copiados byte a byte desde `CORE_CANON_R1_ES`.

Regla central: el **documento original** sigue siendo la fuente primaria. El modo Light no puede reemplazarlo por resumen, memoria, inferencia, comodidad, fragmentos o lectura parcial.

Estado: RC no final. No producción total. No host-ready final. No homologación total. EN bloqueado.
