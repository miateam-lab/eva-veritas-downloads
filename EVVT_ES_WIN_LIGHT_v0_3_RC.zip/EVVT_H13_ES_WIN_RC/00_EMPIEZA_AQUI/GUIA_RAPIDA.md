# GUÍA RÁPIDA — H13 Light ES

1. Identifica el documento original.
2. Usa `PROMPT_LIGERO.txt` para una lectura rápida.
3. Declara si falta fuente, fecha, autoría o contexto.
4. No conviertas una respuesta breve en veredicto final.
5. No resumas ni sustituyas el core: Light es UX ligera, no core reducido.
