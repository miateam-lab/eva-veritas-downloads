# PRUEBA LIGERA

Entrega una afirmación y pide:

1. Documento original o fuente primaria.
2. Evidencia disponible.
3. Qué no se puede concluir.
4. Veredicto provisional breve.
