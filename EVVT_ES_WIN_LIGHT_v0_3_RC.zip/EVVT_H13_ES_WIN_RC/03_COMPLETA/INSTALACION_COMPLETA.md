# INSTALACIÓN COMPLETA — H13 Light ES

1. Instala o entrega los seis archivos `EV_CORE_*_ES.md`.
2. Usa `PROMPT_COMPLETO.txt` si la lectura rápida no basta.
3. Mantén el documento original como fuente primaria.
4. No confundas interfaz ligera con reducción doctrinal.
5. No uses este paquete como autorización productiva o release final.
