# EMPIEZA AQUÍ — EVA Veritas H06 NotebookLM ES Windows

Estado: no productivo, no release final, no homologación total.

Esta cápsula corresponde al lote H06 NotebookLM ES de EVA Veritas v0.3 RC. Continúa desde QA_103R12 H05 Perplexity ES, sin empezar de cero.

Regla crítica: conserva siempre el documento original. En NotebookLM, una respuesta con enlaces o citas no sustituye el documento original. El documento original es la base de contraste para preguntas, verificaciones, fechas, fuentes y límites.

Qué contiene:
- Prompt ligero para uso rápido en NotebookLM.
- Prompt completo para instalación controlada en NotebookLM.
- Núcleo ES copiado desde CORE_CANON_R1_ES sin reescritura.
- Instrucciones de prueba para verificar búsqueda, citas, documento original, límites y ausencia de línea inglesa.
- Registro de fallback: no existe fuente `EV_HOST_NOTEBOOKLM_ES`; por tanto no se inventa ese archivo.
- Registro COCO: no existe antecedente USER_SIMPLE directo para NotebookLM; USER_SIMPLE no se absorbe como core ni como fuente host vigente.

No declares: release final, producción total, host-ready final ni homologación total.
