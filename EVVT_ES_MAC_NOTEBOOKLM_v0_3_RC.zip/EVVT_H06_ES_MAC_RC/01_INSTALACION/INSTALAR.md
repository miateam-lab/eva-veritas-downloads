# INSTALAR — EVA Veritas H06 NotebookLM ES macOS

## Instalación mínima

1. Copia el contenido de `02_LIGERA/PROMPT_LIGERO.txt` en NotebookLM.
2. Abre una conversación nueva para cada prueba crítica.
3. Adjunta o pega el documento original que será analizado.
4. Pide al host que muestre fuentes, fechas y nivel de confianza.
5. No agregues archivos de línea inglesa ni documentos no auditados.

## Instalación completa

1. Copia `03_COMPLETA/PROMPT_COMPLETO.txt`.
2. Adjunta los seis archivos `EV_CORE_*_ES.md` de `04_CONOCIMIENTO/` si el host lo permite.
3. No adjuntes `06_CONTROL/` al host. Control y checksums son para auditoría.
4. Ejecuta `01_INSTALACION/PRUEBA.md` antes de usar resultados.

Regla de instalación: el documento original debe permanecer disponible y distinguible del análisis, de las fuentes web y de la inferencia. Si NotebookLM mezcla esas capas sin distinguirlas, la prueba falla.
