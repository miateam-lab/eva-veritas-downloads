# PRUEBA LIGERA

Pega el prompt ligero en ChatGPT Project y entrega una afirmación sin documento original.

Debe responder con cautela y pedir documento original. Si cierra fuerte sin fuente, falla.


## Nota de recuperación 112R1
Este artefacto fue recuperado/regenerado bajo SOURCE_FIRST desde `CORE_CANON_R1_ES`. No usa 102R6 ni USER_SIMPLE como core. El documento original sigue siendo obligatorio.
