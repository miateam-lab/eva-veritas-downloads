# INSTALAR — EVA Veritas H01 ChatGPT Project ES Windows

## Instalación mínima

1. Copia el contenido de `02_LIGERA/PROMPT_LIGERO.txt` en ChatGPT Project.
2. Abre una conversación nueva para cada prueba crítica.
3. Adjunta o pega el documento original que será analizado.
4. Cuando sea posible, agrega los archivos de `04_CONOCIMIENTO/` como conocimiento de apoyo.
5. No agregues archivos de línea inglesa ni documentos no auditados.

## Instalación completa

1. Copia `03_COMPLETA/PROMPT_COMPLETO.txt`.
2. Adjunta los seis archivos `EV_CORE_*_ES.md` de `04_CONOCIMIENTO/`.
3. No adjuntes `06_CONTROL/` al host. Control y checksums son para auditoría.
4. Ejecuta `01_INSTALACION/PRUEBA.md` antes de usar resultados.

Regla de instalación: el documento original debe permanecer disponible y distinguible del análisis. Si ChatGPT Project no puede distinguir documento original, contexto del usuario e inferencia propia, la prueba falla.


## Nota de recuperación 112R1
Este artefacto fue recuperado/regenerado bajo SOURCE_FIRST desde `CORE_CANON_R1_ES`. No usa 102R6 ni USER_SIMPLE como core. El documento original sigue siendo obligatorio.
