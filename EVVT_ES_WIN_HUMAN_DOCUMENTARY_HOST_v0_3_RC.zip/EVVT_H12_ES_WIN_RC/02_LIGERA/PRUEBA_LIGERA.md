# PRUEBA LIGERA

Entrega un texto o caso documental y pide:

1. Qué documento original existe.
2. Qué parte depende de interpretación humana.
3. Qué evidencia falta.
4. Qué riesgos éticos o de privacidad existen.
