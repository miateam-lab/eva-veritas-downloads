# LEGAL 01 — Método CC0 e identidad oficial

EVA Veritas puede estudiarse, copiarse y adaptarse como método abierto. La identidad oficial, marca, logo y paquetes controlados pertenecen a ARCorp/MIA. Este archivo no declara release final.
