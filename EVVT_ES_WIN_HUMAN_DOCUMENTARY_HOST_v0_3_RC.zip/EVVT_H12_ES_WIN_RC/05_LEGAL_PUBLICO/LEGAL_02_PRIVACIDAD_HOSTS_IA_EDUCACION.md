# LEGAL 02 — Privacidad, hosts humanos y documentación

No subas datos sensibles, expedientes privados, fuentes protegidas, entrevistas confidenciales ni material personal sin consentimiento. El Host Documental Humano exige revisión humana responsable y preservación del documento original.
