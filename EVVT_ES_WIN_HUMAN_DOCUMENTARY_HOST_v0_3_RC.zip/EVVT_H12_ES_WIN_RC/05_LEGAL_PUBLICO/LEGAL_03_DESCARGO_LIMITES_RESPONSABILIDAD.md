# LEGAL 03 — Descargo y límites

EVA Veritas es una herramienta de lectura crítica y apoyo educativo/documental. No sustituye criterio profesional, autorización editorial, consentimiento informado, asesoría legal ni verificación humana completa.
