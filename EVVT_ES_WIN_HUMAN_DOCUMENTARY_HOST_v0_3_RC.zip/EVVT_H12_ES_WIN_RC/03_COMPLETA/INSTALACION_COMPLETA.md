# INSTALACIÓN COMPLETA — H12 Host Documental Humano ES

1. Instala o entrega los seis archivos `EV_CORE_*_ES.md`.
2. Usa `PROMPT_COMPLETO.txt`.
3. Mantén el documento original como pieza primaria.
4. Registra si falta consentimiento, fuente o contexto.
5. No uses este paquete como autorización legal, editorial o productiva.
