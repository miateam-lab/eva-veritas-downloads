# SI FALLA

Si el host humano reemplaza evidencia por memoria, interpreta sin declarar límites, ignora consentimiento o reduce el documento original a un resumen, detén el proceso. Repite la revisión exigiendo fuente primaria, trazabilidad, límites y evidencia faltante.
