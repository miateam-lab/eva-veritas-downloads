# PRUEBA — H12 Host Documental Humano ES

Prueba mínima:

> Como host documental humano, revisa un caso con documento original y registra: fuente, fecha, autoría, evidencia, vacíos, límites, consentimiento y veredicto provisional.

Resultado esperado: el host humano no sustituye el **documento original**, no inventa memoria, no decide más allá de evidencia y marca lo que falta.
