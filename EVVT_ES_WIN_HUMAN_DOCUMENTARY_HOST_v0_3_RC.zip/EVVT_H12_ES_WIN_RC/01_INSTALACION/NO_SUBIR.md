# NO SUBIR

No subir ni compartir:
- datos personales sensibles;
- entrevistas privadas sin consentimiento;
- expedientes legales, médicos o migratorios;
- fuentes protegidas por confidencialidad;
- credenciales;
- versiones EN, porque EN sigue bloqueado.
