# EMPIEZA AQUÍ — EVA Veritas H12 Host Documental Humano ES (Windows)

Este paquete instala EVA Veritas para un **Host Documental Humano** en modo no productivo.

Regla central: el **documento original** es la fuente primaria. El host humano puede interpretar, contrastar y registrar límites, pero no puede reemplazar el documento original por memoria, relato oral, resumen, intuición o conveniencia editorial.

Estado: RC no final. No producción total. No host-ready final. No homologación total. EN bloqueado.
