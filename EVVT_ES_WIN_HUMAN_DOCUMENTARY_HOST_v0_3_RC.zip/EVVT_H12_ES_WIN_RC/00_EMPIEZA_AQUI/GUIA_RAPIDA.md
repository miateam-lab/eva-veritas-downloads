# GUÍA RÁPIDA — H12 Host Documental Humano ES

1. Reúne el documento original o declara que falta.
2. Usa `PROMPT_LIGERO.txt` o `PROMPT_COMPLETO.txt` como guía de revisión humana asistida.
3. Registra fuente, fecha, autoría, contexto, evidencia disponible y evidencia faltante.
4. No conviertas una interpretación humana en veredicto final sin trazabilidad.
5. Mantén consentimiento, privacidad y límites documentales.
