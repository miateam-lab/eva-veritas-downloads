# INSTALACIÓN COMPLETA — H07 DeepSeek ES

Usa esta instalación cuando quieras probar el lote de forma más exigente.

1. Copia `PROMPT_COMPLETO.txt` en DeepSeek.
2. Adjunta los archivos de `04_CONOCIMIENTO/` si el host lo permite.
3. Mantén el documento original separado y claramente identificado.
4. Ejecuta la prueba documental de `01_INSTALACION/PRUEBA.md`.
5. Si se prueba API, todo debe ser sandbox documental: sin claves reales, sin escritura externa, sin datos sensibles.
6. Guarda respuestas y observaciones para QA_103R14.

No subas carpeta de control al host. No conviertas esta instalación en aprobación final.
