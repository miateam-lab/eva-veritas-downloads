# NO SUBIR AL HOST

No subas a DeepSeek:
- `06_CONTROL/`
- `CHECKSUMS.sha256.json`
- `MANIFEST.json`
- `DEEPSEEK_SOURCE_AUDIT_102R14.json`
- archivos de línea inglesa
- documentos privados o sensibles sin autorización
- credenciales API, tokens, secretos, endpoints internos o logs reales
- material que no pueda verificarse contra el documento original

Esta cápsula no contiene `EV_HOST_DEEPSEEK_ES.md` porque no se encontró fuente verificada. Crear ese archivo desde memoria rompería la regla no-inventar.
