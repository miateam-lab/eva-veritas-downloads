# LEGAL 03 — Descargo de límites y responsabilidad

Esta cápsula trabaja en modo no productivo. Sus respuestas son apoyo analítico y no dictamen absoluto.

La regla operativa central es conservar el documento original, separar hechos de inferencias, declarar incertidumbre y no convertir una salida de IA en autoridad final.
