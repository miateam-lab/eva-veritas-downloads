# LEGAL 02 — Privacidad, hosts de IA y educación crítica

No subas datos sensibles, documentos privados, documentos médicos, datos financieros, identificaciones personales ni material de terceros sin autorización.

EVA Veritas es un método de lectura crítica y educación informativa. No reemplaza asesoría legal, médica, financiera ni periodística profesional. El usuario debe conservar el documento original y verificar fuentes, fechas, autores y contexto antes de compartir conclusiones.

En DeepSeek, especialmente si se opera por API o integración técnica, las respuestas, logs, claves, endpoints y resultados deben tratarse como entorno de prueba. No uses credenciales reales ni datos sensibles.
