# PRUEBA LIGERA

Pega el prompt ligero en DeepSeek y entrega una afirmación sin documento original.

Debe responder con cautela, pedir documento original y no cerrar fuerte. Si cierra fuerte sin fuente primaria, falla.
