# GUÍA RÁPIDA — H03 Gemini ES Windows

1. Abre Gemini en un entorno de prueba.
2. Usa `02_LIGERA/PROMPT_LIGERO.txt` para una prueba rápida o `03_COMPLETA/PROMPT_COMPLETO.txt` para instalación más fuerte.
3. Sube solo los archivos de `04_CONOCIMIENTO/` si el host permite adjuntos de conocimiento.
4. No subas `06_CONTROL/` al host de trabajo; esa carpeta es para auditoría.
5. Mantén visible el documento original que vas a analizar.
6. Pide a Gemini que cite qué parte del documento original sostiene cada inferencia.
7. Si el documento original no está disponible, Gemini debe declarar evidencia insuficiente.

Regla transversal: documento original obligatorio en prompt, prueba e instalación. Sin documento original no hay cierre fuerte.
